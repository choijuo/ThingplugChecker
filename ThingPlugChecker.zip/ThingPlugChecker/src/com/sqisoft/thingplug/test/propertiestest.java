package com.sqisoft.thingplug.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.Properties;

public class propertiestest {
	public propertiestest() {
		
		
		try {
			String propfile="config.properties";
			
			Properties props=new Properties();
			FileInputStream fis=new FileInputStream(propfile);
			props.load(new java.io.BufferedInputStream(fis));
			
			
			
			if(props.getProperty("abc")==null) {
				props.setProperty("abc", "def!");
				props.store(new java.io.BufferedOutputStream(new FileOutputStream("config.properties")),"Config");
				
			}
			props.list(System.out);
			
			String msg=props.getProperty("abc");
			System.out.println(msg);
			
			}catch(Exception e) {
				e.printStackTrace();
			}
		
		
		
	}
	public static void main(String[] args) {
		new propertiestest();
	}

}

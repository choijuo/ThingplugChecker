package com.sqisoft.thingplug.test;

import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

//import com.sqisoft.thingplug.Selenium_ThingPlug.Bye;

public class DaemonChrome extends Thread{

	WebDriver driver;
	
    public DaemonChrome() {
    	this.driver=driver;
	}
	
	static void executeChromeDriver() {
		//Runtime.getRuntime().addShutdownHook(new Bye());
		//WebDriver driver=new ChromeDriver();
		
		String DRIVER_ID = "webdriver.chrome.driver";
		String DRIVER_PATH = "chromedriver.exe";
		String base_url = "https://thingplugsvc.sktiot.com:10082";
		System.setProperty(DRIVER_ID, DRIVER_PATH);
		
		ChromeOptions options=new ChromeOptions();
		//options.addArguments("headless");
		WebDriver driver = new ChromeDriver(options);
		
		System.out.println("ThingPlug�� �����մϴ�...");
		driver.get(base_url);
					
		
		
	}//executeChromeDriver
	
	@Override
	public void run() {
			try {
				Thread.sleep(2000);
			}catch(InterruptedException e) {
		
			}//catch
			executeChromeDriver();
	
		
	}//run
}

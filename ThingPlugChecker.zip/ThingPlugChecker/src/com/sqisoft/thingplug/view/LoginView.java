package com.sqisoft.thingplug.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import com.sqisoft.thingplug.controller.LoginEvt;



@SuppressWarnings("serial")
public class LoginView extends JFrame{
	private JTextField jtfId;
	private JButton btnLogin;
	private JButton btnClose;
	private JDialog jdLog;
	private JTextArea updArea;
	private JScrollPane panelLog;
	private String updTxt="\n\n[ver 1.2]\nLora ���� ��� �߰�\n-�⺻ ������ config.properties ���ϻ��� (������ uKey üũ����)\n\n\n\n\n[ver 1.1]\n�α��� ��, ����̽� ���̵� ��ȸ�� �߻��ϴ� ���ǿ��� ����ó�� ";
	public LoginView() {
		super("ThingPlugChecker");
		
		jtfId = new JTextField(20);
		btnLogin = new JButton("�α���");
		btnClose = new JButton("���");
		jdLog=new JDialog(this,"������Ʈ�α�");
		updArea=new JTextArea();
		
		jtfId.setBorder(new TitledBorder("ID"));
		
		//����̹��� �߰�
		URL url=LoginView.class.getClassLoader().getResource("login.png");
		ImageIcon icon = new ImageIcon(url);
		JPanel background = new JPanel() {
		public void paint(Graphics g) {
			g.drawImage(icon.getImage(), 0, 0, null);
			}
		};
		
		
		//��Ʈ ����(�α��� ��ư�� �ݱ� ��ư�� �۾� ��Ʈ ����)
		Font font = new Font("�޸�����ü", Font.ITALIC,20);
		btnLogin.setFont(font);
		btnClose.setFont(font);

		setLayout(null);//������ġ
				
		// ���̵� ��ġ
		//jtfId.setBackground(Color.WHITE);
		background.add(jtfId);
		jtfId.setBounds(110, 125, 215, 60);
		jtfId.setOpaque(false);

		setLayout(null);

		// ��ư��ġ
		btnLogin.setBounds(100, 450, 120, 45);
		btnClose.setBounds(230, 450, 120, 45);
		
		//���̾�α׹�ġ
		updArea.append(updTxt);
		updArea.setFont(new Font("�޸ո���ü",Font.PLAIN,15));
		updArea.setEditable(false);
		panelLog=new JScrollPane(updArea);
		jdLog.add(panelLog);
		jdLog.setResizable(false);
		
		jdLog.setBounds(400,100,450,500);
		jdLog.setVisible(true);
		
		add(jtfId);
		add(btnLogin);
		add(btnClose);
		background.setBounds(0, 0, 450, 600);
		add(background);
		
		
		LoginEvt le = new LoginEvt(this); 
		jtfId.addActionListener(le);
		btnLogin.addActionListener(le);
		btnClose.addActionListener(le);
		
		addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				if(LoginEvt.isCheckSite()==true) {
					LoginEvt.getDriver().close();
					LoginEvt.getDriver().quit();
				}
				dispose();
			}
		});
		

		setBounds(200, 200, 450, 570);
		setResizable(false);
		//setUndecorated(true);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}
	public JTextField getJtfId() {
		return jtfId;
	}
	public JButton getBtnLogin() {
		return btnLogin;
	}
	public JButton getBtnClose() {
		return btnClose;
	}
}

package com.sqisoft.thingplug.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import com.sqisoft.thingplug.controller.SearchEvt;
import com.sqisoft.thingplug.controller.LoginEvt;

@SuppressWarnings("serial")
public class SearchView extends JFrame{
	private JTextField devId;
	private JButton btnSearch;
	private JButton btnExit;
	private JButton btnReset;
	//private LoginView lv;
	private JTextArea resultArea;
	private JScrollPane panelResult;
	private JFrame jf;
	public SearchView() {
		super("ThingPlugChecker");
		
		devId=new JTextField(40);//����̽� ���̵� �˻��ʵ�
		btnSearch=new JButton("�˻�");//�˻���ư
		btnReset=new JButton("����̽� ����");
		btnExit=new JButton("����");//���� ��ư
		resultArea=new JTextArea(6,30);//�гο� ���� textarea
		
		devId.setBorder(new TitledBorder("Device ID"));
		//devId.setBackground(Color.WHITE);
		
		//��Ʈ����(�˻� & ���� ��ư ��Ʈ����)
		Font font=new Font("�޸ո���ü",Font.BOLD,20);
		btnSearch.setFont(font);
		btnReset.setFont(font);
		btnExit.setFont(font);
		
		setLayout(null);//������ġ
		
		//����̽� ���̵� ��ġ
		devId.setBounds(50, 30, 250, 50);
		devId.setOpaque(false);

		setLayout(null);//������ġ
		
		//��ư��ġ
		btnSearch.setBounds(200,800,120,45);
		btnReset.setBounds(320,30,150,45);
		btnExit.setBounds(350,800,120,45);
		
		setLayout(null);
		
		resultArea.setBorder(new TitledBorder("������ �Ľ� ���"));
		resultArea.setEditable(false);
		//resultArea.setBackground(Color.WHITE);
		//resultArea.setBounds(50,100,400,500);
		
		panelResult=new JScrollPane(resultArea);//������� ��� �г�
		
		
		panelResult.setBackground(Color.WHITE);
		panelResult.setBounds(50,100,600,650);
		
		add(devId);
		add(panelResult);
		add(btnSearch);
		add(btnReset);
		add(btnExit);
		
		//��ú�Ȱ��ȭ
		//btnReset.setEnabled(false);

		
		SearchEvt se=new SearchEvt(this);
		devId.addActionListener(se);
		btnSearch.addActionListener(se);
		btnReset.addActionListener(se);
		btnExit.addActionListener(se);
		
		addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				LoginEvt.getDriver().close();
				LoginEvt.getDriver().quit();
			}
		});
		
		setBounds(150, 120, 700, 900);
		setResizable(false);
		setVisible(true);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
	public JTextField getDevId() {
		return devId;
	}
	public JButton getBtnSearch() {
		return btnSearch;
	}
	public JButton getBtnExit() {
		return btnExit;
	}
	public JTextArea getResultArea() {
		return resultArea;
	}
	public void setResultArea(JTextArea resultArea) {
		this.resultArea = resultArea;
	}
	public JButton getBtnReset() {
		return btnReset;
	}
	
	
}

package com.sqisoft.thingplug.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;
import javax.swing.JProgressBar;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.sqisoft.thingplug.view.LoginView;
import com.sqisoft.thingplug.view.SearchView;



public class LoginEvt extends WindowAdapter implements ActionListener{
	Thread thread;
	JProgressBar bar;
	private LoginView lv;
	private static String DRIVER_ID;
	private static String DRIVER_PATH;
	private static String base_url;
	private static ChromeDriver driver;
	private static ChromeOptions options;
	private static WebElement btn_login_first;//ThingPlug���� �α���â Ȱ��ȭ ���� ��ư
	private static WebElement text_box_id;//ID�Է�â
	private static WebElement text_box_pw;//PW�Է�â
	private static WebElement btn_login_second;//ID,PW �Է��� ������ �α��� ��ư
	private static WebElement my_page;
	
	private static String uKey;//�������� ������ �ִ� ���� uKey
	
	private static WebElement btn_menu;//������ ����� �޴� ��ư
	private static WebElement btn_device_log_monitoring;//����̽� �α� ����͸� ��ư
	private static WebElement radio_device_id;//����̽� ���̵� üũ�ϴ� radio��ư
	private static WebDriverWait wait;

	private static Properties props;
	private static FileInputStream fis;
	private static String propfile="config.properties";
	
	private static String login_id;
	
	private static JProgressBar jpb;
	
	private static boolean checkSite=false;
	public LoginEvt(LoginView lv) {
		this.lv = lv;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		login_id = lv.getJtfId().getText().trim();// TextField�� id�� ������� �о�鿩 id�� ����
		
		if(ae.getSource()==lv.getJtfId()) {
			if(login_id.isEmpty()) {
				JOptionPane.showMessageDialog(lv, "���̵��Է�����", "���̵�üũ", JOptionPane.ERROR_MESSAGE);
			}else {
				try {
				loginCheck(login_id);
				}catch(ElementClickInterceptedException ece) {
					JOptionPane.showMessageDialog(lv, "���� �������� �ٽ� Ű����");
					driver.close();
					driver.quit();
					return;
					
				}
			}
		}
		
		
		/////////////////////////////// ��ư���� �α��� �ϱ�/////////////////////////////////
		if (ae.getSource() == lv.getBtnLogin()) {// �α��� ��ư Ŭ���� �̺�Ʈ �߻�
			if(login_id.isEmpty()) {
				JOptionPane.showMessageDialog(lv, "���̵��Է�����", "���̵�üũ", JOptionPane.ERROR_MESSAGE);
			}else {

				try {
					loginCheck(login_id);
				}catch(ElementClickInterceptedException ece) {
					JOptionPane.showMessageDialog(lv, "���� �������� �ٽ� Ű����");
					driver.close();
					driver.quit();
					System.exit(0);
					
				}
			}
		}
		
		if (ae.getSource() == lv.getBtnClose()) {///////////////// �ݱ� ��ư Ŭ���� ����//////
			if(checkSite==true) {
				driver.close();
				driver.quit();
			}
				
			lv.dispose();
			}
		
	
	}//actionPerformed
	
	
	private void loginCheck(String id) throws ElementClickInterceptedException{
		//waitingLogin();
		if(checkSite==false) {
		
		DRIVER_ID = "webdriver.chrome.driver";
		DRIVER_PATH = "chromedriver.exe";
		base_url = "https://thingplugsvc.sktiot.com:10082";
		System.setProperty(DRIVER_ID, DRIVER_PATH);
		options=new ChromeOptions();
		options.addArguments("headless");
		driver=new ChromeDriver(options);
		driver.get(base_url);
		}
		checkSite=true;
	
		wait=new WebDriverWait(driver, 10);
		
		btn_login_first=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("log_in")));
		btn_login_first.click();
		
		text_box_id=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("id")));
		text_box_id.clear();
		text_box_id.sendKeys(id);
		
		text_box_pw=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
		text_box_pw.clear();
		text_box_pw.sendKeys("sqisoft74307!");
		try {
		btn_login_second=wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("btn_blue_big")));
		btn_login_second.click();
		
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		///�α��� �� config.properties �о uKey üũ�ϱ�				
		props=new Properties();
		fis=new FileInputStream(propfile);
		props.load(new java.io.BufferedInputStream(fis));
		
		//config.properties ���� �ȿ� �Է��� ���̵��� uKey �� ������
		if(props.getProperty(id)==null) {
			//driver.findElement(By.cssSelector("#util_menu > li:nth-child(4) > a")).click();
			my_page=wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#util_menu > li:nth-child(4) > a")));
			my_page.click();
			
			uKey=wait.until(ExpectedConditions.visibilityOfElementLocated
						(By.cssSelector("#contents_area > div:nth-child(2) > div.mw_sel_dvc > div > span"))).getText();
			
			//System.out.println(uKey);
			
			props.setProperty(id, uKey);
			props.store(new java.io.BufferedOutputStream(new FileOutputStream(propfile)), "Config");
			
		}
		
		//System.out.println(props.getProperty(id));
		
		btn_menu=wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#util_menu > li.btn_gnb > a > span")));
		
		//FileInputStream ���� ���� �߻�ó�� 
		}catch(IOException e) {
			JOptionPane.showMessageDialog(lv, "properties ������ ���ų� or ����", "Error", JOptionPane.CLOSED_OPTION);
			return;
		}catch(NoSuchElementException | ElementClickInterceptedException e) {
	
			driver.findElement(By.cssSelector("#btnPopOk")).click();
			driver.findElement(By.cssSelector("#util_menu > li:nth-child(1) > div > a")).click();
			text_box_id.clear();
			text_box_pw.clear();
			JOptionPane.showMessageDialog(lv, "���̵�or��й�ȣ�� Ʋ���ϴ�.", "Error", JOptionPane.CLOSED_OPTION);
			
			return;
		}
		btn_menu.click();
		
		btn_device_log_monitoring=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("M010002130")));
		btn_device_log_monitoring.click();
		
		radio_device_id=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='cond' and @value='1']")));
		radio_device_id.click();
		
		lv.dispose();
		new SearchView();
		
	}//logincheck()
	

	

	public static ChromeDriver getDriver() {
		return driver;
	}

	public static WebDriverWait getWait() {
		return wait;
	}

	public LoginView getLv() {
		return lv;
	}

	public void setLv(LoginView lv) {
		this.lv = lv;
	}

	public static boolean isCheckSite() {
		return checkSite;
	}

	public static void setCheckSite(boolean checkSite) {
		LoginEvt.checkSite = checkSite;
	}

	public static String getuKey() {
		return uKey;
	}

	public static Properties getProps() {
		return props;
	}

	public static String getLogin_id() {
		return login_id;
	}

	


	
	
	
	
}

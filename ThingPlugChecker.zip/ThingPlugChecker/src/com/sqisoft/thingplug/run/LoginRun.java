package com.sqisoft.thingplug.run;


import com.sqisoft.thingplug.view.LoginView;

public class LoginRun {

	public static void main(String[] args) {
		new LoginView();
	}

}
